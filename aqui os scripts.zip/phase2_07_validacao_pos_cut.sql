-- ============================================================
-- Phase 2.07 - Post-cut validation
-- Read-only validation after cutover, before freeze_off.
-- Raises on objective leak indicators.
-- ============================================================

SET search_path = public;

SELECT COUNT(*) AS total_students_pos_cut
FROM public.students;

SELECT COUNT(*) AS total_linked_pos_cut
FROM public.students
WHERE linked_auth_user_id IS NOT NULL;

SELECT COUNT(*) AS total_created_by_pos_cut
FROM public.students
WHERE created_by_auth_user_id IS NOT NULL;

SELECT linked_auth_user_id, COUNT(*) AS total
FROM public.students
WHERE linked_auth_user_id IS NOT NULL
GROUP BY linked_auth_user_id
HAVING COUNT(*) > 1;

SELECT s.id, s.linked_auth_user_id, up.role, up.is_super_admin
FROM public.students s
JOIN public.user_profiles up ON up.id = s.linked_auth_user_id
WHERE s.linked_auth_user_id IS NOT NULL
  AND (
        up.role <> 'aluno'
     OR COALESCE(up.is_super_admin, FALSE) = TRUE
  );

SELECT COUNT(*) AS treinos_sem_student
FROM public.treinos t
LEFT JOIN public.students s ON s.id = t.student_id
WHERE t.student_id IS NOT NULL
  AND s.id IS NULL;

SELECT COUNT(*) AS avaliacoes_sem_student
FROM public.avaliacoes a
LEFT JOIN public.students s ON s.id = a.student_id
WHERE a.student_id IS NOT NULL
  AND s.id IS NULL;

SELECT COUNT(*) AS anamneses_sem_student
FROM public.anamneses a
LEFT JOIN public.students s ON s.id = a.student_id
WHERE a.student_id IS NOT NULL
  AND s.id IS NULL;

SELECT COUNT(*) AS assinaturas_sem_student
FROM public.assinaturas a
LEFT JOIN public.students s ON s.id = a.student_id
WHERE a.student_id IS NOT NULL
  AND s.id IS NULL;

SELECT s.id AS student_id, COUNT(*) AS readable_by_alunos
FROM public.students s
JOIN public.user_profiles actor
  ON actor.role = 'aluno'
 AND public.phase2_can_read_student_as(actor.id, s.id)
GROUP BY s.id
HAVING COUNT(*) > 1
ORDER BY readable_by_alunos DESC, s.id;

SELECT actor.id AS aluno_id, s.id AS student_id, s.linked_auth_user_id, s.created_by_auth_user_id
FROM public.user_profiles actor
JOIN public.students s
  ON actor.role = 'aluno'
 AND public.phase2_can_read_student_as(actor.id, s.id)
WHERE s.linked_auth_user_id IS DISTINCT FROM actor.id
ORDER BY actor.id, s.id;

SELECT reason, COUNT(*) AS total
FROM public.student_link_reconciliation
GROUP BY reason
ORDER BY reason;

DO $$
DECLARE
    v_duplicate_links INTEGER;
    v_invalid_role_links INTEGER;
    v_leak_multiple_alunos INTEGER;
    v_leak_wrong_aluno INTEGER;
BEGIN
    SELECT COUNT(*)
    INTO v_duplicate_links
    FROM (
        SELECT linked_auth_user_id
        FROM public.students
        WHERE linked_auth_user_id IS NOT NULL
        GROUP BY linked_auth_user_id
        HAVING COUNT(*) > 1
    ) q;

    IF v_duplicate_links > 0 THEN
        RAISE EXCEPTION 'Validacao pos-cut falhou: linked_auth_user_id duplicado.';
    END IF;

    SELECT COUNT(*)
    INTO v_invalid_role_links
    FROM public.students s
    JOIN public.user_profiles up ON up.id = s.linked_auth_user_id
    WHERE s.linked_auth_user_id IS NOT NULL
      AND (
            up.role <> 'aluno'
         OR COALESCE(up.is_super_admin, FALSE) = TRUE
      );

    IF v_invalid_role_links > 0 THEN
        RAISE EXCEPTION 'Validacao pos-cut falhou: linked_auth_user_id aponta para role invalida.';
    END IF;

    SELECT COUNT(*)
    INTO v_leak_multiple_alunos
    FROM (
        SELECT s.id
        FROM public.students s
        JOIN public.user_profiles actor
          ON actor.role = 'aluno'
         AND public.phase2_can_read_student_as(actor.id, s.id)
        GROUP BY s.id
        HAVING COUNT(*) > 1
    ) q;

    IF v_leak_multiple_alunos > 0 THEN
        RAISE EXCEPTION 'Validacao pos-cut falhou: um student pode ser lido por mais de um aluno.';
    END IF;

    SELECT COUNT(*)
    INTO v_leak_wrong_aluno
    FROM public.user_profiles actor
    JOIN public.students s
      ON actor.role = 'aluno'
     AND public.phase2_can_read_student_as(actor.id, s.id)
    WHERE s.linked_auth_user_id IS DISTINCT FROM actor.id;

    IF v_leak_wrong_aluno > 0 THEN
        RAISE EXCEPTION 'Validacao pos-cut falhou: existe aluno lendo student que nao esta vinculado a ele.';
    END IF;
END $$;
